//
//  PayCore.h
//  PayCore
//
//  Created by Steve Sykes on 10/3/18.
//  Copyright © 2018 Payrix Holdings, LLC.  All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for PayCore.
FOUNDATION_EXPORT double PayCoreVersionNumber;

//! Project version string for PayCore.
FOUNDATION_EXPORT const unsigned char PayCoreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PayCore/PublicHeader.h>


