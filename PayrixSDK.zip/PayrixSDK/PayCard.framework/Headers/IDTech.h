
/*
#import <IDTech/IDT_Device.h>
#import <IDTech/IDT_BTPay.h>
#import <IDTech/IDT_BTMag.h>
#import <IDTech/IDT_iMag.h>
#import <IDTech/IDT_UniPay.h>
#import <IDTech/IDT_UniMag.h>
#import <IDTech/IDTMSRData.h>
#import <IDTech/IDTEMVData.h>
#import <IDTech/IDTUtility.h>
#import <IDTech/APDUResponse.h>
#import <IDTech/IDT_VP3300.h>
#import <IDTech/IDT_NEO2.h>
#import <IDTech/IDT_UniPayI_V.h>
#import <IDTech/uniMag.h>
*/
